from django import forms
from newapp.models import Students

class Studentform (forms.ModelForm):
    class Meta:
        model=Students
        fields="__all__"