from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from newapp.forms import Studentform
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import *
# Create your views here.
def Home(request):
    return render(request,"index.html")

def About(request):
    return render(request,"about.html")

def Cart(request):
    return render(request,"cart.html")
def checkout(request):
    return render(request,"checkout.html" )
def contactus(request):
    return render(request,"contact-us.html")
def gallery(request):
    return render(request,"gallery.html")
def myaccount(request):
    return render(request,"my-account.html")
def shopdetail(request):
    return render(request,"shop-detail.html")
def shop(request):
    return render(request,"shop.html")
def wishlist(request):
    return render(request,"wishlist.html")

def action_page(request):
    
    form=Studentform(request.POST)
    if form.is_valid():
        try:
            form.save()
            return HttpResponse("<h1> SUCCESS </h1>")
        except:
            pass
    return HttpResponse("<h1> ERROR </h1>")

def register(request):
    if request.method=="POST":
        firstname=request.POST['firstname']
        middlename=request.POST['middlename']
        lastname=request.POST['lastname']
        gender=request.POST['gender']
        phone=request.POST['phone']
        currentaddres=request.POST['currentaddres']
        email=request.POST['email']
        password=request.POST['password']
         
        form=Students(firstname=firstname,middlename=middlename,lastname=lastname,phone=phone,currentaddres=currentaddres,email=email,password=password,gender=gender)
        form.save()
        messages.success(request,'The new user'+request.POST['firstname']+"is saved")
        return render(request,'login.html')
    else:
        return render(request,'register.html')

def login(request):
    if request.method=="POST":
        email=request.POST['email']
        password=request.POST['password']
        if Students.objects.filter(email=email,password=password).exists():
            isLogged=Students.objects.get(email=email, password=password)
            return render(request,'index.html',{'firstname':isLogged.firstname})
        else:
            return render(request,'login.html',{'msg':'Login Failed'})
    else:
        return render(request,'login.html')
