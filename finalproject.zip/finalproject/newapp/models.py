from django.db import models

# Create your models here.

class Students(models.Model):
    firstname = models.CharField(max_length=30)
    middlename = models.CharField(max_length=20)
    lastname = models.CharField(max_length=20)
    gender =models.CharField(max_length=20)
    phone =models.CharField(max_length=25)
    currentaddres =models.CharField(max_length=160)
    email = models.CharField(max_length=40,unique=True)
    password = models.CharField(max_length=30)

    class Meta:
        db_table = "project"
    
class Products(models.Model):
    product_name=models.CharField(max_length=140)
    amount=models.CharField(max_length=20)
    quantity=models.IntegerField()
    class Meta:
        db_table="Products"